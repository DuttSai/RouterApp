import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {Routes,RouterModule} from '@angular/router'

import { AppComponent } from './app.component';
import { RouterComponent } from './router/router.component';
import { AddComponent } from './add/add.component';
import {FormsModule} from '@angular/forms'
const appRoutes:Routes=[
  {path:"",redirectTo:'/getdata',pathMatch:'full'},
  {path:'getdata',component:RouterComponent},
  {path:'adddata',component:AddComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    RouterComponent,
    AddComponent
  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
