import { Component } from '@angular/core';
import { Emp } from './emp';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
//  empArr:Emp[]=[
//   {id:1001,empName:"Sai",empSal:20000,empDep:"javascript"},
//   {id:1002,empName:"Ranjit",empSal:454545,empDep:"asjkfba"},
//   {id:1003,empName:"Nava",empSal:78789,empDep:"bjyt"},
//   {id:1004,empName:"Sagar",empSal:15151,empDep:"rtryyht"},
//   {id:1005,empName:"Anand",empSal:41516,empDep:"cdfdgdh"},
//   {id:1006,empName:"Srikar",empSal:798552,empDep:"edgjnfj"}
// ]
name:string='saidutt'
// tempArr:any[]=[]
// samArr:Emp[]=[]
//  i:number=0;
//  j:number=0;
// idClick(){
//   this.i=0;
//   this.j=0;
//   console.log("id clicked")
//   this.empArr.map(x=>
//     {
//       this.tempArr.push(x.id)
//     })

//     this.tempArr.sort()
//     console.log(this.tempArr)
//     for(let t=0;t<=this.empArr.length;t++)
//     { 
//       for(let a of this.empArr){
//       if(a.id==this.tempArr[this.i]){
//         console.log(a);
//         this.samArr[this.j]=a;
//         this.j++
//       }
      
//     }
//     this.i++
//   }
//   this.i=0
//   this.empArr.map(m=>{
//     this.empArr[this.i]=this.samArr[this.i]
//     this.i++
//   })
// this.tempArr=[]
// }
// nameClick(){
//   this.i=0;
//   this.j=0;
//   console.log("name clicked")
//   this.empArr.map(x=>
//     {
//       this.tempArr.push(x.empName)
//     })

//     this.tempArr.sort()
//     console.log(this.tempArr)
//     for(let t=0;t<=this.empArr.length;t++)
//     { 
//       for(let a of this.empArr){
//       if(a.empName==this.tempArr[this.i]){
//         console.log(a);
//         this.samArr[this.j]=a;
//         this.j++
//       }
      
//     }
//     this.i++
//   }
//   this.i=0
//   this.empArr.map(m=>{
//     this.empArr[this.i]=this.samArr[this.i]
//     this.i++
//   })
//   this.tempArr=[]
// }
// salClick(){
//   this.i=0;
//   this.j=0;
//   console.log("id clicked")
//   this.empArr.map(x=>
//     {
//       this.tempArr.push(x.empSal)
//     })

//     this.tempArr.sort()
//     console.log(this.tempArr)
//     for(let t=0;t<=this.empArr.length;t++)
//     { 
//       for(let a of this.empArr){
//       if(a.empSal==this.tempArr[this.i]){
//         console.log(a);
//         this.samArr[this.j]=a;
//         this.j++
//       }
      
//     }
//     this.i++
//   }
//   this.i=0
//   this.empArr.map(m=>{
//     this.empArr[this.i]=this.samArr[this.i]
//     this.i++
//   })
//   this.tempArr=[]
// }
// depClick(){
//   this.i=0;
//   this.j=0;
//   console.log("id clicked")
//   this.empArr.map(x=>
//     {
//       this.tempArr.push(x.empDep)
//     })

//     this.tempArr.sort()
//     console.log(this.tempArr)
//     for(let t=0;t<=this.empArr.length;t++)
//     { 
//       for(let a of this.empArr){
//       if(a.empDep==this.tempArr[this.i]){
//         console.log(a);
//         this.samArr[this.j]=a;
//         this.j++
//       }
      
//     }
//     this.i++
//   }
//   this.i=0
//   this.empArr.map(m=>{
//     this.empArr[this.i]=this.samArr[this.i]
//     this.i++
//   })
//   this.tempArr=[]
// }

}
