import { Component, OnInit } from '@angular/core';
import { EmpserviceService } from '../empservice.service';
import { Emp } from '../emp';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css'],
  providers:[EmpserviceService]
})
export class AddComponent implements OnInit {
empObj:Emp=new Emp()
  constructor(private empservice:EmpserviceService) { }

  ngOnInit() {
  }
  addEmp(empObj:Emp){
this.empservice.addEmp(empObj)

  }

}
