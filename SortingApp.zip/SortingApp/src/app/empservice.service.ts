import { Injectable } from '@angular/core';
import { Emp } from './emp';
import {RouterComponent} from './router'
@Injectable()
export class EmpserviceService {

  constructor() { }
  empArr1:Emp[]=[
    {id:1001,empName:"Sai",empSal:20000,empDep:"javascript"},
    {id:1002,empName:"Ranjit",empSal:454545,empDep:"asjkfba"},
    {id:1003,empName:"Nava",empSal:78789,empDep:"bjyt"},
    {id:1004,empName:"Sagar",empSal:15151,empDep:"rtryyht"},
    {id:1005,empName:"Anand",empSal:41516,empDep:"cdfdgdh"},
    {id:1006,empName:"Srikar",empSal:798552,empDep:"edgjnfj"}
  ]
  addEmp(empObj:Emp){
    this.empArr1.push(empObj)

    console.log(this.empArr1)
  }
  getEmp(){
    console.log("from service:"+this.empArr1)
    return this.empArr1

  }
  

}
