import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';
import { EmpserviceService } from '../empservice.service';

@Component({
  selector: 'app-router',
  templateUrl: './router.component.html',
  styleUrls: ['./router.component.css'],
  providers:[EmpserviceService]
})
export class RouterComponent implements OnInit {

  constructor(private empservice:EmpserviceService) { }

  ngOnInit() {
    console.log(this.empservice.getEmp())

  }
  
  empArr:Emp[]=this.empservice.getEmp();
  

}
module.exports=RouterComponent